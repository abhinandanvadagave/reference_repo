package com.bootOne.bootOneProject.service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bootOne.bootOneProject.entity.StudentEntity;
import com.bootOne.bootOneProject.model.Student;
import com.bootOne.bootOneProject.repository.StudentRepository;

@Service
public class StudentService {

	private final static Logger LOGGER = LoggerFactory.getLogger(StudentService.class);
	
	@Autowired
	StudentRepository repository;
	
	public List<Student> getAllStudents() {
		List<Student> studentsList = null;
		
		try {
			List<StudentEntity> studentEntity = repository.findAll();
			studentsList = studentEntity.parallelStream().map(s -> s.convertEntityToModel()).collect(Collectors.toList());
		} catch(Exception e) {
			LOGGER.error("Error while getting all students", e);
		}
		return studentsList;
	}
	
	public Student getStudentById(Long id) {
		
		Optional<StudentEntity> studentEntity = null;
		Student student = new Student();
		
		try {
			studentEntity = repository.findById(id);
			student = studentEntity.get().convertEntityToModel();
		} catch(Exception e) {
			LOGGER.error("Error while getting student", e);
		}
		return student;
	}
	
	public void addStudent(Student student) {
		try {
			repository.save(student.convertModelToEntity());
		} catch (Exception e) {
			LOGGER.error("Upload new book operation failed", e);
		}
	}
}
