package com.bootOne.bootOneProject.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bootOne.bootOneProject.entity.EmployeeEntity;
import com.bootOne.bootOneProject.repository.EmployeeRepository;

@Service
public class EmployeeService {

	private final static Logger LOGGER = LoggerFactory.getLogger(EmployeeService.class);
	
	@Autowired
	EmployeeRepository employeeRepository;
	
	public List<EmployeeEntity> getAllEmpVehicles() {
		List<EmployeeEntity> employeeEntities = new ArrayList<EmployeeEntity>();
		try {
			employeeEntities = employeeRepository.findAll();
		} catch(Exception e) {
			LOGGER.error("Error while getting Vehicles by employee", e);
		}
		
		return employeeEntities;
	}
	
	public List<EmployeeEntity> addEmployee(EmployeeEntity employeeEntity) {
		try {
			employeeRepository.save(employeeEntity);
		} catch(Exception e) {
			LOGGER.error("Error while registering Vehicles", e);
		}
		
		return getAllEmpVehicles();
	}
	
	public EmployeeEntity getEmpVehicles(String empCode) {
		
		EmployeeEntity employeeEntity = new EmployeeEntity();
		
		try {
			Optional<EmployeeEntity> employeeEntityOptional = employeeRepository.findById(empCode);
			employeeEntity = employeeEntityOptional.get();
		} catch(Exception e) {
			LOGGER.error("Error while getting Vehicles by employee", e);
		}
		
		return employeeEntity;
	}
	
	public List<EmployeeEntity> removeEmployee(String empCode) {
		
		try {
			employeeRepository.deleteById(empCode);
		} catch(Exception e) {
			LOGGER.error("Error while getting Vehicles by employee", e);
		}

		return getAllEmpVehicles();
	}
}
