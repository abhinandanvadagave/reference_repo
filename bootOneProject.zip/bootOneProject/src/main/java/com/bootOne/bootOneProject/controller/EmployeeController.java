package com.bootOne.bootOneProject.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bootOne.bootOneProject.entity.EmployeeEntity;
import com.bootOne.bootOneProject.service.EmployeeService;

@RestController
@RequestMapping("/park")
public class EmployeeController {

	@Autowired
	EmployeeService employeeService;
	
	@GetMapping("/getAllEmployees")
	public List<EmployeeEntity> getEmployees() {
		
		return employeeService.getAllEmpVehicles();
	}
	
	@GetMapping("/getEmployeeVehicles/{empCode}")
	public EmployeeEntity getEmpVehicles(@PathVariable String empCode) {
		
		EmployeeEntity employeeEntity = new EmployeeEntity();
		
		employeeEntity = employeeService.getEmpVehicles(empCode);
		return employeeEntity;
	}
	
	@PostMapping("/addEmployee")
	public List<EmployeeEntity> addEmployee(@RequestBody EmployeeEntity employeeEntity) {
		
		return employeeService.addEmployee(employeeEntity);
	}
	
	@DeleteMapping("/removeEmployee/{empCode}")
	public List<EmployeeEntity> removeEmployee(@PathVariable String empCode) {
		
		return employeeService.removeEmployee(empCode);
	}
}
