package com.bootOne.bootOneProject.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.bootOne.bootOneProject.model.Employee;

@Entity
@Table(name="employee")
public class EmployeeEntity {
	
	@Id
	@Column
	private String empCode;
	
	@Column
	private String empName;

	@OneToMany(cascade=CascadeType.ALL)
	@JoinColumn(name="empCode", nullable = false)
    private List<VehicleEntity> vehiclesList;
	
	public String getEmpCode() {
		return empCode;
	}

	public void setEmpCode(String empCode) {
		this.empCode = empCode;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}
	
	public Employee convertEntityToModel() {
		Employee employee = new Employee();
		
		employee.setEmpCode(this.empCode);
		employee.setEmpName(this.empName);
				
		return employee;
	}

	public List<VehicleEntity> getVehiclesList() {
		return vehiclesList;
	}

	public void setVehiclesList(List<VehicleEntity> vehiclesList) {
		this.vehiclesList = vehiclesList;
	}
}
