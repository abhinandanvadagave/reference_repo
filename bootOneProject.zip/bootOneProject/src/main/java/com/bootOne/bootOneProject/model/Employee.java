package com.bootOne.bootOneProject.model;

import java.util.List;

import com.bootOne.bootOneProject.entity.EmployeeEntity;

public class Employee {
	String empCode;
	String empName;
	
	private List<Vehicle> vehiclesList;
	
	public String getEmpCode() {
		return empCode;
	}
	public void setEmpCode(String empCode) {
		this.empCode = empCode;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	
	public EmployeeEntity convertModelToEntity() {
		EmployeeEntity employeeEntity = new EmployeeEntity();
		
		employeeEntity.setEmpCode(this.empCode);
		employeeEntity.setEmpName(this.empName);
		
		return employeeEntity;
	}

	public List<Vehicle> getVehiclesList() {
		return vehiclesList;
	}

	public void setVehiclesList(List<Vehicle> vehiclesList) {
		this.vehiclesList = vehiclesList;
	}
}
