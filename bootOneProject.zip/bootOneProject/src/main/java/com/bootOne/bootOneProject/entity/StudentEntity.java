package com.bootOne.bootOneProject.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.bootOne.bootOneProject.model.Student;

@Entity
@Table(name="student")
public class StudentEntity {

	@Id
	@Column(name="id")
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Long id;
	
	@Column(name="name")
	private String name;
	
	@Column(name="_class")
	private String _class;
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String get_class() {
		return _class;
	}

	public void set_class(String _class) {
		this._class = _class;
	}
	
	public Student convertEntityToModel() {
		Student student = new Student();
		student.setId(this.id);
		student.setName(this.name);
		student.set_class(this._class);
		
		return student;
	}
}
