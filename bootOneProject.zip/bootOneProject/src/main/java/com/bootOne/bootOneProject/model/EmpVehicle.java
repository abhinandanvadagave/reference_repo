package com.bootOne.bootOneProject.model;

import com.bootOne.bootOneProject.entity.EmpVehicleEntity;

public class EmpVehicle {
	String empCode;
	String empName;
	String vehicleType;
	String vehicleNumber;
	
	public EmpVehicle() {}
	
	public EmpVehicle(String empCode, String empName, String vehicleType, String vehicleNumber) {
		this.empCode = empCode;
		this.empName = empName;
		this.vehicleType = vehicleType;
		this.vehicleNumber = vehicleNumber;
	}

	public String getEmpCode() {
		return empCode;
	}

	public void setEmpCode(String empCode) {
		this.empCode = empCode;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public String getVehicleType() {
		return vehicleType;
	}

	public void setVehicleType(String vehicleType) {
		this.vehicleType = vehicleType;
	}

	public String getVehicleNumber() {
		return vehicleNumber;
	}

	public void setVehicleNumber(String vehicleNumber) {
		this.vehicleNumber = vehicleNumber;
	}
	
	public EmpVehicleEntity convertModelToEntity() {
		EmpVehicleEntity empVehicleEntity = new EmpVehicleEntity();
		
		empVehicleEntity.setEmpCode(this.empCode);
		empVehicleEntity.setEmpName(this.empName);
		empVehicleEntity.setVehicleType(this.vehicleType);
		empVehicleEntity.setVehicleNumber(this.vehicleNumber);
		
		return empVehicleEntity;
	}
}
