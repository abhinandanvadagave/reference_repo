package com.bootOne.bootOneProject.model;

import com.bootOne.bootOneProject.entity.VehicleEntity;

public class Vehicle {
	String vehicleType;
	String vehicleNumber;
	
	public String getVehicleType() {
		return vehicleType;
	}
	public void setVehicleType(String vehicleType) {
		this.vehicleType = vehicleType;
	}
	public String getVehicleNumber() {
		return vehicleNumber;
	}
	public void setVehicleNumber(String vehicleNumber) {
		this.vehicleNumber = vehicleNumber;
	}
	
	public VehicleEntity convertModelToEntity() {
		VehicleEntity vehicleEntity = new VehicleEntity();
		
		vehicleEntity.setVehicleType(this.vehicleType);
		vehicleEntity.setVehicleNumber(this.vehicleNumber);
		
		return vehicleEntity;
	}
}
