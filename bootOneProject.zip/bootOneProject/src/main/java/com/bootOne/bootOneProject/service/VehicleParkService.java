package com.bootOne.bootOneProject.service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bootOne.bootOneProject.entity.EmpVehicleEntity;
import com.bootOne.bootOneProject.model.EmpVehicle;
import com.bootOne.bootOneProject.repository.VehicleParkReository;

@Service
public class VehicleParkService {
	
	private final static Logger LOGGER = LoggerFactory.getLogger(VehicleParkService.class);
	
	@Autowired
	VehicleParkReository vehicleParkReository;
	
	public List<EmpVehicle> getAllParkedVehicles() {
		List<EmpVehicle> empVehiclesList = null;
		
		try {
			List<EmpVehicleEntity> empVehicleEntities = vehicleParkReository.findAll();
			empVehiclesList = empVehicleEntities.parallelStream().map(s -> s.convertEntityToModel()).collect(Collectors.toList());
		} catch(Exception e) {
			LOGGER.error("Error while getting all parked Vehicles", e);
		}
		return empVehiclesList;
	}
	
	public EmpVehicle getVehicleByEmployeeCode(String empCode) { 
		EmpVehicle empVehicle = new EmpVehicle();
	  
		try {
			Optional<EmpVehicleEntity> empVehicleEntityOptional = vehicleParkReository.findById(empCode);
			EmpVehicleEntity empVehicleEntity = empVehicleEntityOptional.get();
			
			return empVehicleEntity.convertEntityToModel();
		} catch(Exception e) {
			LOGGER.error("get vehicle by employee operation failed", e);
		}
	  	return empVehicle; 
	}
	 
	public void parkVehicle(EmpVehicle empVehicle) {
		try {
			vehicleParkReository.save(empVehicle.convertModelToEntity());
		} catch (Exception e) {
			LOGGER.error("park vehicle operation failed", e);
		}
	}
	
	public void unparkVehicle(String empCode) {
		
		try {
			vehicleParkReository.deleteById(empCode);
		} catch(Exception e) {
			LOGGER.error("unpark vehicle operation failed", e);
		}
	}
}
