package com.bootOne.bootOneProject.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.bootOne.bootOneProject.entity.EmpVehicleEntity;

@Repository
public interface VehicleParkReository extends JpaRepository<EmpVehicleEntity, String>{

}
