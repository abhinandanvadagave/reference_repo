package com.bootOne.bootOneProject.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bootOne.bootOneProject.model.EmpVehicle;
import com.bootOne.bootOneProject.repository.VehicleParkReository;
import com.bootOne.bootOneProject.service.VehicleParkService;

@RestController
@RequestMapping("/park")
public class VehicleParkController {

	@Autowired
	VehicleParkReository vehicleParkReository;
	
	@Autowired
	VehicleParkService vehicleParkService;
	
	@GetMapping("/getParkedVehicles")
	public List<EmpVehicle> getParkedVehicles() {
		return vehicleParkService.getAllParkedVehicles();
	}
	
	@GetMapping("/getVehicleByEmpCode/{empCode}")
	public EmpVehicle getVehicleByEmpCode(@PathVariable String empCode) {
		return vehicleParkService.getVehicleByEmployeeCode(empCode);
	}
	
	@PostMapping(value = "/parkVehicle")
	public void parkVehicle(@RequestBody EmpVehicle empVehicle) {
		vehicleParkService.parkVehicle(empVehicle);
	}
	
	@PostMapping(value = "/unparkVehicle")
	public List<EmpVehicle> unparkVehicle(@RequestBody String empCode) {
		vehicleParkService.unparkVehicle(empCode);
		return vehicleParkService.getAllParkedVehicles();
	}
}
