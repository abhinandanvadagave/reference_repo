package com.bootOne.bootOneProject.model;

import com.bootOne.bootOneProject.entity.StudentEntity;

public class Student {

	Long id;
	String name;
	String _class;
	
	public Student() {}
	
	public Student(Long id, String name, String _class) {
		this.id = id;
		this.name = name;
		this._class = _class;
	}
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String get_class() {
		return _class;
	}
	public void set_class(String _class) {
		this._class = _class;
	}
	
	public StudentEntity convertModelToEntity() {
		StudentEntity studentEntity = new StudentEntity();
		
		studentEntity.setId(this.id);
		studentEntity.setName(this.name);
		studentEntity.set_class(this._class);
		
		return studentEntity;
	}
}
