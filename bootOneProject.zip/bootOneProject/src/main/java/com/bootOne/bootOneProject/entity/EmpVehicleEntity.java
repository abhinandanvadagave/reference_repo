package com.bootOne.bootOneProject.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.bootOne.bootOneProject.model.EmpVehicle;

@Entity
@Table(name="emp_vehicle")
public class EmpVehicleEntity {
	
	@Id
	@Column
	private String empCode;
	
	@Column
	private String empName;
	
	@Column
	private String vehicleType;
	
	@Column
	private String vehicleNumber;

	public String getEmpCode() {
		return empCode;
	}

	public void setEmpCode(String empCode) {
		this.empCode = empCode;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public String getVehicleType() {
		return vehicleType;
	}

	public void setVehicleType(String vehicleType) {
		this.vehicleType = vehicleType;
	}

	public String getVehicleNumber() {
		return vehicleNumber;
	}

	public void setVehicleNumber(String vehicleNumber) {
		this.vehicleNumber = vehicleNumber;
	}
	
	public EmpVehicle convertEntityToModel() {
		EmpVehicle empVehicle = new EmpVehicle();
		
		empVehicle.setEmpCode(this.empCode);
		empVehicle.setEmpName(this.empName);
		empVehicle.setVehicleType(this.vehicleType);
		empVehicle.setVehicleNumber(this.vehicleNumber);
				
		return empVehicle;
	}
}
