package com.bootOne.bootOneProject.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.bootOne.bootOneProject.model.Vehicle;

@Entity
@Table(name = "vehicle")
public class VehicleEntity {

	@Id
    @Column
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Long id;

    @Column
    private String vehicleType;

    @Column
    private String vehicleNumber;
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getVehicleType() {
		return vehicleType;
	}

	public void setVehicleType(String vehicleType) {
		this.vehicleType = vehicleType;
	}

	public String getVehicleNumber() {
		return vehicleNumber;
	}

	public void setVehicleNumber(String vehicleNumber) {
		this.vehicleNumber = vehicleNumber;
	}
	
	public Vehicle convertEntityToModel() {
		Vehicle vehicle = new Vehicle();
		
		vehicle.setVehicleType(this.vehicleType);
		vehicle.setVehicleNumber(this.vehicleNumber);
				
		return vehicle;
	}
}