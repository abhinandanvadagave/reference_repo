package com.employee.management.service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.employee.management.entity.EmployeeEntity;
import com.employee.management.model.Employee;
import com.employee.management.repository.EmployeeRepository;

@Service
public class EmployeeService {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(EmployeeService.class);
	@Autowired
	private EmployeeRepository employeeRepository;
	
	// getting all employees
	public List<Employee> getAllEmployees(){
		List<EmployeeEntity> employeeList = new ArrayList<>();
		try {
			employeeList = (List<EmployeeEntity>) employeeRepository.findAll();
			
		} catch(Exception e) {
			LOGGER.error("Error while getting all employee details", e);
		}
		return employeeList.parallelStream()
				.map(EmployeeEntity::convertEntityToModel)
				.collect(Collectors.toList());
	}
	
	// getting employee by id
	public Employee getEmployee(int id){
		Employee employee = new Employee();
		try {
			employee = employeeRepository.findOne(id).convertEntityToModel();
		} catch(Exception e) {
			LOGGER.error("Error while getting employee by id", e);
		}
		return employee;
	}
	
	// adding employee
	public void addEmployee(Employee e) {
		try {
			employeeRepository.save(e.convertModelToEntity());
		} catch(Exception ex) {
			LOGGER.error("Error while adding employee", ex);
		}
	}
	
	// updating employee by id
	public void updateEmployee(Employee emp, int id){
		try {
			if(id == emp.getEmployeeId()) {
				employeeRepository.save(emp.convertModelToEntity());
			}
		} catch(Exception e) {
			LOGGER.error("Error while updating employee", e);
		}
	}
	
	// deleting employee by id
	public void deleteEmployeeById(int id){
		try {
			employeeRepository.delete(id);
		} catch(Exception e) {
			LOGGER.error("Error while deleting employee by id", e);
		}
	}
}
