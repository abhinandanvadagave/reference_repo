package com.employee.management.repository;

import org.springframework.data.repository.CrudRepository;

import com.employee.management.entity.EmployeeEntity;

// interface extending crud repository
public interface EmployeeRepository extends CrudRepository<EmployeeEntity, Integer>{
	
}
