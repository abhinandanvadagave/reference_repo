package com.employee.management.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.employee.management.model.Department;

@Entity
@Table(name="department")
public class DepartmentEntity {

	@Id
	@Column(name="department_id")
	private int departmentId;
	
	@Column
	private String shortName;
	
	@Column
	private String departmentName;
	
	public DepartmentEntity() {
	
	}
	
	public DepartmentEntity(int departmentId){
		super();
		this.departmentId = departmentId;
	}
	
	public DepartmentEntity(int departmentId, String shortName, String departmentName) {
		super();
		this.departmentId = departmentId;
		this.shortName = shortName;
		this.departmentName = departmentName;
	}

	public int getDepartmentId() {
		return departmentId;
	}

	public void setDepartmentId(int departmentId) {
		this.departmentId = departmentId;
	}

	public String getShortName() {
		return shortName;
	}

	public void setShortName(String shortName) {
		this.shortName = shortName;
	}

	public String getDepartmentName() {
		return departmentName;
	}

	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}
	
	public Department convertEntityToModel() {
		Department dept = new Department();
		
		dept.setDepartmentId(this.departmentId);
		dept.setDepartmentName(this.departmentName);
		dept.setShortName(this.shortName);
		
		return dept;
	}

	@Override
	public String toString() {
		return "DepartmentEntity [departmentId=" + departmentId + ", shortName=" + shortName + ", departmentName="
				+ departmentName + "]";
	}
}
