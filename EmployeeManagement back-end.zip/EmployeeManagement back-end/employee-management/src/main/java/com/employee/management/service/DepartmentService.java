package com.employee.management.service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.employee.management.entity.DepartmentEntity;
import com.employee.management.model.Department;
import com.employee.management.repository.DepartmentRepository;

@Service
public class DepartmentService {

	private static final Logger LOGGER = LoggerFactory.getLogger(DepartmentService.class);
	@Autowired
	private DepartmentRepository departmentRepository;
	

	// getting all departments
	public List<Department> getAllDepartments(){
		List<DepartmentEntity> listDeptsEntities = new ArrayList<>();
		try {
			listDeptsEntities = (List<DepartmentEntity>)departmentRepository.findAll(); 
		} catch(Exception e) {
			LOGGER.error("Error while getting all departments details", e);
		}
		
		return listDeptsEntities.parallelStream()
				.map(DepartmentEntity::convertEntityToModel)
				.collect(Collectors.toList());
	}
	
	// getting department by id
	public Department getDepartmentById(int id){
		Department department = new Department();
		try {
			department = departmentRepository.findOne(id).convertEntityToModel();
		} catch(Exception e) {
			LOGGER.error("Error while getting department by id", e);
		}
		return department;
	}
	
	// inserting department
	public void addDepartment(Department d) {
		try {
			departmentRepository.save(d.convertModelToEntity());
		} catch(Exception e) {
			LOGGER.error("Error while adding department", e);
		}
	}
	
	// updating department by id
	public void updateDepartment(Department d, int id){
		try {
			if(id == d.getDepartmentId()) {
				departmentRepository.save(d.convertModelToEntity());
			}
		} catch(Exception e) {
			LOGGER.error("Error while updating department", e);
		}
	}
	
	// deleting department by id
	public void deleteDepartmentById(int id){
		try {
			departmentRepository.delete(id);
		} catch(Exception e) {
			LOGGER.error("Error while deleting department by id", e);
		}
	}
}
