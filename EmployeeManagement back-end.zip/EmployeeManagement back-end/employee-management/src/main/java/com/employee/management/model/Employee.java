package com.employee.management.model;

import com.employee.management.entity.DepartmentEntity;
import com.employee.management.entity.EmployeeEntity;

public class Employee {

	private int employeeId;
	
	private String firstName;
	
	private String lastName;
	
	private DepartmentEntity department;
	
	public Employee(){
		
	}
	
	public Employee(String firstName, String lastName, DepartmentEntity department) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.department = department;
	}
	
	public int getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public DepartmentEntity getDepartment() {
		return department;
	}

	public void setDepartment(DepartmentEntity department) {
		this.department = department;
	}
	
	public EmployeeEntity convertModelToEntity() {
		EmployeeEntity empEntity = new EmployeeEntity();
		
		empEntity.setEmployeeId(this.employeeId);
		empEntity.setFirstName(this.firstName);
		empEntity.setLastName(this.lastName);
		empEntity.setDepartment(this.department);
		
		return empEntity;
	}

	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", firstName=" + firstName + ", lastName=" + lastName
				+ ", department=" + department + "]";
	}
}
