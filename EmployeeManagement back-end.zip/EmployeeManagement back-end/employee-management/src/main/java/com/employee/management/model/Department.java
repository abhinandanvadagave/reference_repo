package com.employee.management.model;

import com.employee.management.entity.DepartmentEntity;

public class Department {

	private int departmentId;
	private String shortName;
	private String departmentName;
	
	public Department() {
	
	}
	
	public Department(int departmentId){
		super();
		this.departmentId = departmentId;
	}
	
	public Department(int departmentId, String shortName, String departmentName) {
		super();
		this.departmentId = departmentId;
		this.shortName = shortName;
		this.departmentName = departmentName;
	}

	public int getDepartmentId() {
		return departmentId;
	}

	public void setDepartmentId(int departmentId) {
		this.departmentId = departmentId;
	}

	public String getShortName() {
		return shortName;
	}

	public void setShortName(String shortName) {
		this.shortName = shortName;
	}

	public String getDepartmentName() {
		return departmentName;
	}

	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}

	public DepartmentEntity convertModelToEntity() {
		DepartmentEntity deptEntity = new DepartmentEntity();
		
		deptEntity.setDepartmentId(this.departmentId);
		deptEntity.setDepartmentName(this.departmentName);
		deptEntity.setShortName(this.shortName);
		
		return deptEntity;
	}

	@Override
	public String toString() {
		return "Department [departmentId=" + departmentId + ", shortName=" + shortName + ", departmentName="
				+ departmentName + "]";
	}
}
