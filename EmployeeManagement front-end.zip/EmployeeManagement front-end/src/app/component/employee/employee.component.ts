import { Component, OnInit } from '@angular/core';
import { EmployeeService } from 'src/app/service/employee/employee.service';
import { Employee } from 'src/app/model/employee';
import { Department } from 'src/app/model/department';
import { DepartmentService } from 'src/app/service/department/department.service';
import { ConfirmationDialogService } from 'src/app/confirmation-dialog/confirmation-dialog.service';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {

  formTitle = '';
  promptStatement = '';

  employee: Employee = new Employee();
  department: Department [];
  result: Employee [];
  constructor(private empService: EmployeeService, private deptService: DepartmentService,
    private confirmationDialogService: ConfirmationDialogService) { }

  getAllEmployeesDetails() {
    this.empService.getAllEmployees()
        .subscribe(res => {
          if (res.length < 1) {
            this.formTitle = 'No records found!';
            this.result = null;
          } else {
            this.formTitle = 'Employee Details';
            this.result = res;
          }
        });
  }

  getEmployeeById(empId: string) {

    if (isNaN(this.employee.employeeId)) {
      this.promptStatement = 'Employee Id should be a number!';
    } else {
      this.promptStatement = '';
      this.empService.getEmployeeById(empId)
      .subscribe(res => console.log(res.employeeId + '  ' + res.firstName));
    }
  }

  addEmployee() {
    this.employee.department = this.department.find(d => d.departmentId.toString() === this.employee.department.toString());
    this.empService.addEmployee(this.employee)
    .subscribe(res => {
      if (res.length < 1) {
        this.formTitle = 'No records found!';
        this.result = null;
      } else {
        this.formTitle = 'Employee Details';
        this.result = res;
        this.employee = new Employee();
      }
    });
  }

  ngOnInit() {
    this.deptService.getAllDepts()
    .subscribe(depts => {
      this.department = depts;
    });
    this.getAllEmployeesDetails();
  }

  public openConfirmationDialog(employeeId: string) {
    this.confirmationDialogService.confirm('Please confirm.', 'Do you really want to delete?')
    .then(confirmed => { if (confirmed) {
        this.empService.deleteEmployeeById(employeeId)
        .subscribe(res => {
          if (res.length < 1) {
            this.formTitle = 'No records found!';
            this.promptStatement = '';
            this.result = null;
          } else {
            this.formTitle = 'Employee Details';
            this.promptStatement = '';
            this.result = res;
          }
        });
      }
    })
    .catch(err => console.log('Error: ' + err));
  }
}
