import { Component, OnInit } from '@angular/core';
import { Department } from 'src/app/model/department';
import { DepartmentService } from 'src/app/service/department/department.service';
import { ConfirmationDialogService } from 'src/app/confirmation-dialog/confirmation-dialog.service';

@Component({
  selector: 'app-department',
  templateUrl: './department.component.html',
  styleUrls: ['./department.component.css']
})

export class DepartmentComponent implements OnInit {

  formTitle = '';
  promptStatement = '';
  department: Department = new Department();
  result: Department [];
  constructor(private deptService: DepartmentService,
    private confirmationDialogService: ConfirmationDialogService) { }

  ngOnInit() {
    this.getAllDepts();
  }

  public getDeptById(deptId) {
    if (isNaN(this.department.departmentId)) {
      this.promptStatement = 'Department Id should be a number!';
    } else {
      this.promptStatement = '';
      this.deptService.getDeptById(deptId)
      .subscribe(res => console.log(res.departmentName));
    }
  }

  public getAllDepts() {
    this.deptService.getAllDepts()
    .subscribe(res => {
      if (res.length < 1) {
        this.formTitle = 'No records found!';
        this.promptStatement = '';
        this.result = null;
      } else {
        this.formTitle = 'Department Details';
        this.promptStatement = '';
        this.result = res;
        this.department = new Department();
      }
    });
  }

  public addDepartment() {
    this.deptService.addDepartment(this.department)
    .subscribe(res => {
      if (res.length < 1) {
        this.formTitle = 'No records found!';
        this.promptStatement = '';
        this.result = null;
      } else {
        this.formTitle = 'Department Details';
        this.promptStatement = '';
        this.result = res;
        this.department = new Department();
      }
    });
  }

  public openConfirmationDialog(deptId: string) {
    this.confirmationDialogService.confirm('Please confirm.', 'Do you really want to delete?')
    .then(confirmed => { if (confirmed) {
        this.deptService.deleteDeptById(deptId)
        .subscribe(res => {
          if (res.length < 1) {
            this.formTitle = 'No records found!';
            this.promptStatement = '';
            this.result = null;
          } else {
            this.formTitle = 'Department Details';
            this.promptStatement = '';
            this.result = res;
          }
        });
      }
    })
    .catch( err => console.log('Error: ' + err));
  }
}
