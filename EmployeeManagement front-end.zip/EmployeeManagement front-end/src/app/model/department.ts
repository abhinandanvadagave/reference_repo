export class Department {
  departmentId: number;
  shortName: string;
  departmentName: string;
}
