import { Department } from './department';

export class Employee {
  employeeId: number;
  firstName: string;
  lastName: string;
  department: Department;
}
