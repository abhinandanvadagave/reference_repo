import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `<ul class='navbar navbar-expand'>
                        <li><a class='nav-link' [routerLink]="['/employee-details']">Employee</a></li>
                        <li><a class='nav-link' [routerLink]="['/department-details']">Department</a></li>
                    </ul>
                    <div class='container'><router-outlet><span class='navbar-brand'><h5>{{title}}</h5></span></router-outlet></div>`,
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Welcome to Employee Management System';
}
