import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Department } from 'src/app/model/department';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DepartmentService {

  getAllDeptsUrl = '/departments';
  getDeptByIdUrl = '/departments';
  addDeptUrl = '/departments';
  deleteDeptByIdUrl = '/departments';
  constructor(private http: HttpClient) { }

  public getAllDepts(): Observable<Department []> {
    return this.http.get<Department []>(this.getAllDeptsUrl);
  }

  public getDeptById(deptId): Observable<Department> {
    return this.http.get<Department>(this.getDeptByIdUrl + '/' + deptId);
  }

  public addDepartment(dept): Observable<Department []> {
    return this.http.post<Department []>(this.addDeptUrl, dept);
  }

  public deleteDeptById(deptId): Observable<Department []> {
    return this.http.delete<Department []>(this.deleteDeptByIdUrl + '/' + deptId);
  }
}
