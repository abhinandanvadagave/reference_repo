import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Employee } from 'src/app/model/employee';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  getAllEmployeesUrl = '/employees';
  getEmployeeByIdUrl = '/employees';
  addEmployeeUrl = '/employees';
  deleteEmployeeByIdUrl = '/employees';
  constructor(private http: HttpClient) { }

  public getAllEmployees(): Observable<Employee []> {
    return this.http.get<Employee []>(this.getAllEmployeesUrl);
  }

  public getEmployeeById(empId): Observable<Employee> {
    return this.http.get<Employee>(this.getEmployeeByIdUrl + '/' + empId);
  }

  public addEmployee(emp): Observable<Employee []> {
    return this.http.post<Employee []>(this.addEmployeeUrl, emp);
  }

  public deleteEmployeeById(emp): Observable<Employee []> {
    return this.http.delete<Employee []>(this.deleteEmployeeByIdUrl + '/' + emp);
  }
}
