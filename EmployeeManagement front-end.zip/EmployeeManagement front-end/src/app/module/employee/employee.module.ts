import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { EmployeeRoutingModule } from './employee-routing.module';
import { NumberDirective } from './numberDirective.directive';
import { EmployeeComponent } from 'src/app/component/employee/employee.component';


@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    EmployeeRoutingModule
  ],
  declarations: [EmployeeComponent, NumberDirective]
})
export class EmployeeModule { }
