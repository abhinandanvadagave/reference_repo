import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { DepartmentRoutingModule } from './department-routing.module';
import { DepartmentComponent } from 'src/app/component/department/department.component';
import { NumberDirective } from './numberDirective.directive';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    DepartmentRoutingModule
  ],
  declarations: [DepartmentComponent, NumberDirective]
})
export class DepartmentModule { }
