import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ParkingStatusRoutingModule } from './parking-status-routing.module';
import { ParkingStatusComponent } from './parking-status.component';
import { EntitiesModule } from '../shared/entities/entities.module';

@NgModule({
  imports: [
    CommonModule,
    ParkingStatusRoutingModule,
    EntitiesModule.forRoot()
  ],
  declarations: [ParkingStatusComponent]
})
export class ParkingStatusModule { }
