import { Component, OnInit } from '@angular/core';
import { ParkService } from '../service/park.service';
import { EmpVehicle } from '../model/emp-vehicle';

@Component({
  selector: 'app-parking-status',
  templateUrl: './parking-status.component.html',
  styleUrls: ['./parking-status.component.css'],
})
export class ParkingStatusComponent implements OnInit {

  constructor(private parkService: ParkService) {}
    public parkStatusHeader = '';

    results: EmpVehicle[];

    ngOnInit(): void {
        this.parkService.getParkingStatus()
        .subscribe(res => {
            this.results = res;
            if (res.length > 0) {
                this.parkStatusHeader = 'Currently Parked Vehicles';
            } else {
                this.parkStatusHeader = 'No any Vehicle Parked!';
            }
        });
    }

    unparkVehicle(empCode) {
        this.parkService.unparkVehicle(empCode)
        .subscribe(res => {
            this.results = res;
            if (res.length > 0) {
                this.parkStatusHeader = 'Currently Parked Vehicles';
            } else {
                this.parkStatusHeader = 'No any Vehicle Parked!';
            }
        });
    }
}
