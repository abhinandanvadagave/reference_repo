import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ParkingStatusComponent } from './parking-status.component';

const routes: Routes = [
  {
    path: '',
    component: ParkingStatusComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ParkingStatusRoutingModule { }
