import { ParkingStatusModule } from './parking-status.module';

describe('ParkingStatusModule', () => {
  let parkingStatusModule: ParkingStatusModule;

  beforeEach(() => {
    parkingStatusModule = new ParkingStatusModule();
  });

  it('should create an instance', () => {
    expect(parkingStatusModule).toBeTruthy();
  });
});
