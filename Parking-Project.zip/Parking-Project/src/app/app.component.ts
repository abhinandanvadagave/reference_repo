import { Component } from '@angular/core';

@Component({
    selector: 'app-root',
    template: `<span class='navbar-brand'><h1>{{title}}</h1></span>
                    <ul class='navbar navbar-expand'>
                        <li><a class='nav-link' [routerLink]="['/parking-status']">Parking Status</a></li>
                        <li><a class='nav-link' [routerLink]="['/park-in']">Park Entry</a></li>
                        <li><a class='nav-link' [routerLink]="['/register']">Register Vehicle</a></li>
                    </ul>
                    <div class='container'><router-outlet></router-outlet></div>`,
    styleUrls: ['./app.component.css']
})
export class AppComponent {
  public title = 'Welcome To Vehicle Parking System';
}
