import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

const routes: Routes = [
  {
    path: 'parking-status',
    loadChildren: './parking-status/parking-status.module#ParkingStatusModule'
  },
  {
    path: 'park-in',
    loadChildren: './parking-entry/parking-entry.module#ParkingEntryModule'
  },
  {
    path: 'register',
    loadChildren: './register-vehicle/register-vehicle.module#RegisterVehicleModule'
  },
  {
    path: 'home',
    loadChildren: './welcome/welcome.module#WelcomeModule'
  },
  {
    path: '',
    redirectTo: '/home',
    pathMatch: 'full'
  },
  {
    path: '**',
    redirectTo: '/home',
    pathMatch: 'full'
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
