import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ParkingEntryRoutingModule } from './parking-entry-routing.module';
import { ParkingEntryComponent } from './parking-entry.component';
import { FormsModule } from '@angular/forms';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ParkingEntryRoutingModule
  ],
  declarations: [ParkingEntryComponent]
})
export class ParkingEntryModule { }
