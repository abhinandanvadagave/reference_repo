import { Component, OnInit } from '@angular/core';
import { Vehicle } from '../model/vehicle';
import { Employee } from '../model/employee';
import { ParkService } from '../service/park.service';

@Component({
  selector: 'app-parking-entry',
  templateUrl: './parking-entry.component.html',
  styleUrls: ['./parking-entry.component.css']
})
export class ParkingEntryComponent implements OnInit {

  public formTitle = 'Make Entry of vehicle for Parking';
    public promptStatement = '';

    vehiclesList: Vehicle = new Vehicle();
    employee: Employee = new Employee();
    public constructor(private parkService: ParkService) {}

    public input: any;
    ngOnInit(): void {}

    getEmployeeVehicles(newHero: string) {
        if (newHero !== '') {
            this.parkService.getEmployeeVehicles(newHero)
            .subscribe(res => {
                if (res.empCode != null) {
                    this.parkService.getVehicleByEmpCode(newHero)
                    .subscribe(result => {
                        if (result.empCode !== null) {
                            this.promptStatement = 'Employee with employee id ' + result.empCode + ' already parked there vehicle!';
                            this.employee = new Employee();
                            this.vehiclesList = new Vehicle();
                        } else {
                            this.employee =  res;
                            this.vehiclesList.vehicleType = res.vehiclesList[0].vehicleType;
                            this.vehiclesList.vehicleNumber = res.vehiclesList[0].vehicleNumber;
                            this.promptStatement = '';
                        }
                    });
                } else {
                    this.promptStatement = 'Employee with employee id ' + this.employee.empCode + ' not registered for parking!';
                    this.employee = new Employee();
                    this.vehiclesList = new Vehicle();
                }
            });
        }
    }
    parkVehicle() {
        this.input = {
            'empCode': this.employee.empCode,
            'empName': this.employee.empName,
            'vehicleType': this.vehiclesList.vehicleType,
            'vehicleNumber': this.vehiclesList.vehicleNumber
            };
        if (this.input.empCode && this.input.vehicleNumber) {
            this.parkService.parkVehicle(this.input);
        }
    }

}
