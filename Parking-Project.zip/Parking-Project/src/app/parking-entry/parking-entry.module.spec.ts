import { ParkingEntryModule } from './parking-entry.module';

describe('ParkingEntryModule', () => {
  let parkingEntryModule: ParkingEntryModule;

  beforeEach(() => {
    parkingEntryModule = new ParkingEntryModule();
  });

  it('should create an instance', () => {
    expect(parkingEntryModule).toBeTruthy();
  });
});
