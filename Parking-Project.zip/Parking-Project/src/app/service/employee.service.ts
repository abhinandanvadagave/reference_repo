import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Employee } from '../model/employee';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
  private registerEmpVehUrl = '/park/addEmployee';
  private getAllEmpVehUrl = '/park/getAllEmployees';
  private removeEmpVehUrl = '/park/removeEmployee';

  private getEmpVehiclesUrl = '/park/getEmployeeVehicles';

   constructor(private http: HttpClient) {}

  getAllEmpVehicles(): Observable<any> {
      return this.http.get(this.getAllEmpVehUrl);
  }

  getEmployeeVehicles(newHero) {
      return this.http.get<Employee>(this.getEmpVehiclesUrl + '/' + newHero);
  }

  registerEmpVehicle(employee): Observable<Employee []> {
      return this.http.post<Employee []>(this.registerEmpVehUrl, (employee));
  }

  removeEmployee(empCode): Observable<Employee []> {
      return this.http.delete<Employee []>(this.removeEmpVehUrl + '/' + empCode);
  }
}
