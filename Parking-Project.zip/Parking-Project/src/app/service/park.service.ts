import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { EmpVehicle } from '../model/emp-vehicle';
import { Employee } from '../model/employee';

@Injectable({
  providedIn: 'root'
})
export class ParkService {
  private geturl = '/park/getParkedVehicles';
  private getEmpVehiclesUrl = '/park/getEmployeeVehicles';
  private getVehByEmpCode = '/park/getVehicleByEmpCode';
  private parkUrl = '/park/parkVehicle';
  private unparkUrl = '/park/unparkVehicle';

  constructor(private http: HttpClient, private router: Router) {}

  getParkingStatus() {
      return this.http.get<EmpVehicle []>(this.geturl);
  }

  getEmployeeVehicles(newHero) {
      return this.http.get<Employee>(this.getEmpVehiclesUrl + '/' + newHero);
  }

  getVehicleByEmpCode(newHero) {
      return this.http.get<Employee>(this.getVehByEmpCode + '/' + newHero);
  }

  parkVehicle(empVehicle) {
      this.http.post(this.parkUrl, empVehicle)
      .subscribe(result => {
                  this.router.navigate(['/parking-status']);
              });
  }
  unparkVehicle(empCode) {
      return this.http.post<EmpVehicle []>(this.unparkUrl, empCode);
  }
}
