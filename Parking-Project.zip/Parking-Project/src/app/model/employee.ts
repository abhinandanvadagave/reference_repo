import { Vehicle } from './vehicle';

export class Employee {
    empCode: string;
    empName: string;
    vehiclesList: Array<Vehicle>;
}
