export class EmpVehicle {
    empCode: string;
    empName: string;
    vehicleType: string;
    vehicleNumber: string;
}
