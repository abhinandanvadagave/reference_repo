export class Vehicle {
    id: number;
    vehicleType: string;
    vehicleNumber: string;
}
