import { Component, OnInit } from '@angular/core';
import { Employee } from '../model/employee';
import { Vehicle } from '../model/vehicle';
import { EmployeeService } from '../service/employee.service';

@Component({
  selector: 'app-register-vehicle',
  templateUrl: './register-vehicle.component.html',
  styleUrls: ['./register-vehicle.component.css']
})
export class RegisterVehicleComponent implements OnInit {

  pageTitle = 'Register Employee Vehicle for Parking';
    vehiclesRegistered = '';
    promptMsg = '';

    input: any;
    emp: Employee = new Employee();
    vehicle: Vehicle = new Vehicle();
    allEmpVehicles: Array<any>;

    constructor(private empService: EmployeeService) {}
    ngOnInit(): void {
        this.empService.getAllEmpVehicles()
        .subscribe(
            res => {
                this.allEmpVehicles = res;
                if (res.length > 0) {
                    this.vehiclesRegistered = 'Employee Vehicle Details';
                } else {
                    this.vehiclesRegistered = 'No any Vehicle Registered!';
                }
            });
    }

    getEmployeeVehicles(newHero: string) {
        if (newHero !== '') {
            this.empService.getEmployeeVehicles(newHero)
            .subscribe(res => {
                if (res.empCode != null) {
                    this.promptMsg = 'Employee already registered for parking!';
                    this.emp = new Employee();
                    this.vehicle = new Vehicle();
                } else {
                    this.promptMsg = '';
                }
            });
        }
    }

    registerEmpVehicle() {

        this.input = {
            'empCode': this.emp.empCode,
            'empName': this.emp.empName,
            'vehiclesList': [{
                'vehicleType': this.vehicle.vehicleType,
                'vehicleNumber': this.vehicle.vehicleNumber
                }]
        };

        if (this.input.empCode && this.input.empName && this.input.vehiclesList.length > 0) {
            this.empService.registerEmpVehicle(this.input)
            .subscribe(result => {
                    this.allEmpVehicles = result;
                    this.emp = new Employee();
                    this.vehicle = new Vehicle();
                    if (result.length > 0) {
                        this.vehiclesRegistered = 'Employee Vehicles Details';
                    } else {
                        this.vehiclesRegistered = 'No any Vehicle Registered!';
                    }
                });
        }
    }

    removeEmployee(empCode) {
        this.empService.removeEmployee(empCode)
        .subscribe(result => {
                   this.allEmpVehicles = result;
                    if (result.length > 0) {
                        this.vehiclesRegistered = 'Employee Vehicles Details';
                    } else {
                        this.vehiclesRegistered = 'No any Vehicle Registered!';
                    }
                });
    }

}
