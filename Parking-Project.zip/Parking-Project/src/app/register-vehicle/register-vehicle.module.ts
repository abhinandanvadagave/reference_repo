import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { RegisterVehicleRoutingModule } from './register-vehicle-routing.module';
import { RegisterVehicleComponent } from './register-vehicle.component';
import { FormsModule } from '@angular/forms';
import { EntitiesModule } from '../shared/entities/entities.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    RegisterVehicleRoutingModule,
    EntitiesModule.forRoot()
  ],
  declarations: [RegisterVehicleComponent]
})
export class RegisterVehicleModule { }
