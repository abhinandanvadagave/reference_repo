import { RegisterVehicleModule } from './register-vehicle.module';

describe('RegisterVehicleModule', () => {
  let registerVehicleModule: RegisterVehicleModule;

  beforeEach(() => {
    registerVehicleModule = new RegisterVehicleModule();
  });

  it('should create an instance', () => {
    expect(registerVehicleModule).toBeTruthy();
  });
});
