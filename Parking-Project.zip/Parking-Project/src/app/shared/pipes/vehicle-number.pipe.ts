import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'vehicleNumberFormat'
})
export class VehicleNumberPipe implements PipeTransform {

  transform(value: string, args?: string): string {
    let temp = value.substr(0, 2).concat(args).concat(value.substr(2, value.length));
    temp = temp.substr(0, 5).concat(args).concat(temp.substr(5, temp.length));
    temp = temp.substr(0, 8).concat(args).concat(temp.substr(8, temp.length));
    return temp;
  }

}
