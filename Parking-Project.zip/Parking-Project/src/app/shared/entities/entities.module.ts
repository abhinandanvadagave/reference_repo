import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { VehicleNumberPipe } from '../pipes/vehicle-number.pipe';

@NgModule({
  imports: [
    CommonModule
  ],
  exports: [VehicleNumberPipe],
  declarations: [VehicleNumberPipe]
})
export class EntitiesModule {
    static forRoot() {
      return {
          ngModule: EntitiesModule,
          providers: []
      };
  }
}
